
public interface NumericTest {
	
	boolean test(int n);

}
