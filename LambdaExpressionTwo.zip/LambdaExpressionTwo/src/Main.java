
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		NumericTest isEven =(n)->(n%2)==0;
		
		if(isEven.test(10)) System.out.println("10 is even");

	}

}
