
public interface MyNumber {
	
	double getValue();

}
