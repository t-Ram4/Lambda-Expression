
public class Main {

	public static void main(String[] args) {
		
		MyNumber myNum;
		
		myNum= ()-> 123.45;
		
		System.out.println("A fixed value "+myNum.getValue());

	}

}
