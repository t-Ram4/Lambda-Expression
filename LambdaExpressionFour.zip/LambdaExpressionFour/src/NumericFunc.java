
public interface NumericFunc {
	
	int func(int n);

}
