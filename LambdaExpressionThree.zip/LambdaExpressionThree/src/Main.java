
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		NumericTest2 isFactor = (n,d)->(n%d)==0;
		
		if(isFactor.test(10, 2))
		System.out.println("2 is a factor of 10");	

	}

}
