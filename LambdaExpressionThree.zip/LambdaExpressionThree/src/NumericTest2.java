
public interface NumericTest2 {
	
	boolean test(int n, int d);

}
